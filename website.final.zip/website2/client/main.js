/* eslint-disable no-undef */
/* eslint-disable no-unused-vars */
// Fetch the product data and populate the product grid
fetch('/coffee')
    .then(response => response.json())
    .then(data => {
    const items = [];
    for (let i = 0; i < data.vertuo.length; i++) {
      const product = data.vertuo[i];
      const item = {
        id: product.id,
        name: product.name,
        type: product.type,
        intensity: product.intensity,
        price: product.price,
        image: product.image,
        quantity: 0
      };
      items.push(item);
    }
    console.log(items);

    const GridContainer = document.querySelector('.all-grid-container');
      for (let i = 0; i < data.vertuo.length; i++) {
        const product = data.vertuo[i];
        // console.log(product);
        // add box container
        const box = document.createElement('div');
        box.classList.add('all-box');
        // add image
        const imageDiv = document.createElement('div');
        // console.log(imageDiv);
        imageDiv.classList.add('all-image');
        const image = document.createElement('img');
        console.log(image);
        // image link
        image.src = product.image;
        // image description
        image.alt = product.name;
        imageDiv.appendChild(image);
        box.appendChild(imageDiv);

        // create text div
        const textDiv = document.createElement('div');
        textDiv.classList.add('all-text');
        // shoiw the name
        const name = document.createElement('h5');
        name.innerHTML = product.name;
        // show the intensity
        const intensity = document.createElement('h6');
        intensity.innerHTML = 'Intensity: ' + product.intensity;
        // show type of coffee
        const type = document.createElement('h6');
        type.innerHTML = product.type;
        // show the price
        const price = document.createElement('span');
        price.classList.add('all-info');
        price.innerHTML = '£' + product.price;

        textDiv.appendChild(name);
        textDiv.appendChild(intensity);
        textDiv.appendChild(type);
        textDiv.appendChild(price);
        box.appendChild(textDiv);

        const clickDiv = document.createElement('div');
        clickDiv.classList.add('all-click');

        // create add button
        const button2 = document.createElement('button');
        button2.classList.add('btn', 'btn-primary', 'all-click');
        button2.type = 'button';
        button2.innerHTML = '+';
        button2.onclick = function () {
          console.log('add to cart');
          addToCart(product);
        };

        clickDiv.appendChild(button2);
        box.appendChild(clickDiv);
        GridContainer.appendChild(box);
      }
    })
    .catch(error => console.error(error));

const cart = [];

function addToCart (product) {
    const existingItem = cart.find(item => item.id === product.id);
    if (existingItem) {
      existingItem.quantity++;
    } else {
      cart.push({
        // spread syntax
        ...product,
        quantity: 1
      });
    }
    showCart();
    // console.log(cart);
  }

function removeFromCart (product) {
    const index = cart.findIndex(item => item.id === product.id);
    if (index !== -1) {
        const item = cart[index];
        item.quantity--;
        if (item.quantity === 0) {
            cart.splice(index, 1);
        }
    }
    showCart();
    // console.log(cart);
}

function calculateTotal () {
  let total = 0;
  cart.forEach(item => {
    total += item.price * item.quantity;
  });
  return total;
}

// Store cart data in local storage
localStorage.setItem('cart', JSON.stringify(cart));

function showCart () {
  const urlParams = new URLSearchParams(window.location.search);
  const cartData = JSON.parse(decodeURIComponent(urlParams.get('cartData')));

  const cartItemsElement = document.getElementById('cartItems');
  cartItemsElement.innerHTML = '';

  cart.forEach(item => {
    const li = document.createElement('li');
    li.innerHTML = `${item.quantity} x ${item.name} - £${item.price * item.quantity}`;
    const removeButton = document.createElement('button');
    removeButton.classList.add('RemoveButton');
    removeButton.onclick = () => removeFromCart(item);
    removeButton.innerHTML = 'Remove';
    li.appendChild(removeButton);
    cartItemsElement.appendChild(li);
  });

  const cartTotalElement = document.getElementById('CartTotal');
  const cartTotal = calculateTotal();
  cartTotalElement.innerHTML = `Total: £${cartTotal}`;
}

// Extract the cart data from the query parameter

function checkout () {
  const checkoutButton = document.getElementById('checkoutButton');
  const cartData = JSON.stringify(cart);
  const xhr = new XMLHttpRequest();
  xhr.open('POST', '/checkout'); // replace with the endpoint on your server that handles the checkout
  xhr.setRequestHeader('Content-Type', 'application/json');
  xhr.send(cartData);
  xhr.open('GET', '/cart');
  xhr.setRequestHeader('Content-Type', 'application/json');
  xhr.onload = function () {
    if (xhr.status === 200) {
      const data = JSON.parse(xhr.responsßeText);
      console.log(data);
    }
  };
}

function updateCart () {
  const xhr = new XMLHttpRequest();
  xhr.open('GET', '/cart');
  xhr.setRequestHeader('Content-Type', 'application/json');
  xhr.onload = function () {
    if (xhr.status === 200) {
      const data = JSON.parse(xhr.responseText);
      cartData = data;
      // Update the cart display
      showCart();
    }
  };
  xhr.send();
}

fetch('/cart')
  .then(response => response.json())
  .then(items => {
    console.log(items);
    const itemList = document.createElement('ul');
    items.forEach(item => {
      const itemElement = document.createElement('li');
      // Create an image element to display the item image
      const imgElement = document.createElement('img');
      imgElement.src = item.image;
      imgElement.alt = item.name;
      imgElement.width = 50;
      itemElement.appendChild(imgElement);
      // Create a text element to display the item name and price
      const textElement = document.createElement('span');
      textElement.textContent = `${item.name} - $${item.price}`;
      itemElement.appendChild(textElement);
      // Create a remove button
      const removeButton = document.createElement('button');
      removeButton.textContent = 'Remove';
      itemElement.appendChild(removeButton);
      // Add an event listener to the remove button
      removeButton.addEventListener('click', () => {
        // Remove the item from the cart
        const index = items.findIndex(i => i.id === item.id);
        items.splice(index, 1);
        // Update the cart on the server
        fetch('/cart', {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(items)
        })
          .then(() => {
            // Remove the item from the DOM
            itemElement.remove();
          })
          .catch(error => console.error(error));
      });
      itemList.appendChild(itemElement);
    });
    document.getElementById('checkoutList').appendChild(itemList);
  })
  .catch(error => console.error(error));
// Store cart data in local storage

// window.addEventListener('click', function(event){
//   fetch('http://127.0.0.1:8081/carts')
//   .then(response => response.text())
//   .then(body =>
//   document.getElementById('content').innerHTML=body)
//  });

// window.addEventListener('click', async function(event){
//   try{
//   let response = await fetch('http://127.0.0.1:8081/carts');
//   let body = await response.text();
//   document.getElementById('content').innerHTML=body;
//   } catch(e) {
//   alert(e);
//   }
//  });
