const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const cart = require('./cart.json');
const coffeeData = require('./coffee.json');
const orders = require('./order.json');

app.use(express.static('client'));

// app.use(express.json());
app.get('/coffee', (req, res) => {
  // Read the product data from coffee.json
  res.json((coffeeData));
});

app.use(bodyParser.json());

// Handle checkout POST request
app.post('/checkout', (req, res) => {
  const items = req.body;
  for (let i = 0; i < items.length; i++) {
    cart.push(items[i]);
  }
  // Send a response indicating success
  res.sendStatus(200);
});

app.get('/cart', (req, res) => {
  res.json(cart);
});

// app.get('/order', (req, res) => {
//   res.json(orders);
// });

app.post('/order', (req, res) => {
  const orderData = req.body;
  orderData.items = cart;
  orders.push(orderData);
  res.sendStatus(200);
});

// // Start the server
app.listen(8081, () => {
  console.log('Server started at http://127.0.0.1:8081');
});
